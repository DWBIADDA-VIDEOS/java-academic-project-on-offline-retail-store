
import java.io.File;
import java.io.FileWriter;
import java.util.*;

  class Sta_menu {

		
	 Scanner s=new Scanner (System.in);
	 String category=""; //To Accept the Category say, Eraser, Pen etc
	 String company="";  // To Accept the company 
	 int quant=0;    // Quantity of item avaialable
	 int price=0;    // Its Price
	 List<Add_menu> add_menu=new ArrayList<Add_menu>();// To Hold the Menu item
	 List<Add_menu> add_cart=new ArrayList<Add_menu>();//To Hold the Cart
    	
	/******************************************/
	/* To Accept the Menu item                */
	/******************************************/
	
	public  void accept_item()
	{
		System.out.print("Enter the Product Category:");
		category=s.next();
		System.out.print("Enter the Company:");
		company=s.next();
		System.out.print("Enter the Quantity:");
		quant=s.nextInt();
		System.out.print("Enter the Cost:");
		price=s.nextInt();	
		adding_item();
	}
        
	/******************************************/
	/* To Add the Accepted Menu item          */
	/******************************************/

	public  void adding_item()
	{
		 Add_menu obj=new Add_menu(category,company,quant,price,add_menu);//Add menu class is called
		 int flag=obj.check_exist();//check the menu item already exist by calling check_exist method that is available in Add_menu class
		//If it is available
		 if(flag!=0) 
		 {
		     System.out.println("Enter 0 to proceed with adding new Quantity to existing item in the menu");
		     System.out.println("Enter 1 to proceed with update the existing item cost to menu");
		     System.out.println("Enter 2 to proceed with update the existing item cost and also add the Quantity to menu");
		     System.out.println("Enter any other number to skip the activity");
			 int update=s.nextInt();
			     if(update==0)
			    	 obj.update_menu(update); // call update menu that in the class Add_menu to add new Quantity
				 else if (update == 1)
				 {
					 obj.update_menu(update);// call update menu that in the class Add_menu to update the item cost
				 }
				 else if (update == 2)
				 {
					 obj.update_menu(update); // call update menu that in the class Add_menu to add new Quantity and update Cost 
				 }
		 }
		 else
		  add_menu.add(obj);//if it is not available then simply the item is added
	}

	/**********************************************/
	/* Check the item is available  add the cart */
	/**********************************************/
	public void checking_cart()
	{
		cart c=new cart(category,company,quant,price,add_menu,add_cart);
		int exist_flag=c.check();
		if(exist_flag == 0)
		{
		System.out.println("Item is not currently avaialble.Sorry for inconvinence!!");
		}
		
	}
	/**********************************************/
	/* Search the item in the menu 		      */
	/**********************************************/
	public void search()
	{
		System.out.print("Enter the Product Category:");
	     String search_Category=s.next().toLowerCase();
		 System.out.print("Enter the Company:");
		 String search_company=s.next().toLowerCase();
		 int search_flag=0;
		for(Add_menu a:add_menu)
		{
			if((a.category.equals(search_Category)) && (a.company.equals(search_company)))
			{
				System.out.println("Category:"+a.category);
				System.out.println("Comapany:"+a.company);
				System.out.println("Quant:"+a.quant);
				System.out.println("Price:"+a.price);
				search_flag++;
			}
		}
		if(search_flag==0)
		{
			System.out.println("Searched item is not available");
		}
	}
	
	public void print()
	{

		for(Add_menu a:add_menu)
		{
			  System.out.println("Category:"+a.category);
			  System.out.println("Comapany:"+a.company);
			  System.out.println("Quant:"+a.quant);
			  System.out.println("Price:"+a.price);	
		}
	}
	public void bill()
	{
		int total_amount=0;
		StringBuffer sb = new StringBuffer();
		for(Add_menu a:add_cart)
		{
			  sb.append("Category - "+a.category);
			  sb.append(" Comapany: "+a.company);
			  sb.append(" (Quant- "+a.quant+" ) ");
			  sb.append("unit - " + a.price);	
			  sb.append(" - " + a.quant*a.price+"\n");
			  total_amount+=(a.quant*a.price);
			  sb.append("");
		}
	  sb.append("\nTotal Bill Amount:"+total_amount+"\n\n");
	   File file=new File("D:\\631110\\Dwbiadda_Stationary_System\\bill");
	  try
	  {
	   if(file.exists())
	  {
  	  FileWriter fw= new FileWriter(file);
  	  fw.write(sb.toString());
  	  fw.close();
	  }
	  else
	  {
		  System.out.println("File not Found");
	  }
	   Scanner scanner = new Scanner(file);
		 
		 while (scanner.hasNextLine()) {
		     
			 String part =scanner.nextLine();
			 System.out.println(part);
	   }
		 System.out.println(" ");
	  }
	  catch(Exception e)
	  {
		  System.out.println(e.getMessage());
	  }
	}
	
}
