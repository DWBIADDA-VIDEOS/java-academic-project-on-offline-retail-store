import java.util.*;
public class cart {
	 String category;
	 String company;
	 int quant;
	 int price;
	 List<Add_menu> check_menu=new ArrayList<Add_menu>();
	 List<Add_menu> add_cart=new ArrayList<Add_menu>();
	 
	cart(String category,String company,int quant,int price,List<Add_menu> add_menu,List<Add_menu> add_cart)
	{
		this.category=category;
		this.company=company;
		this.quant=quant;
		this.price=price;
		this.check_menu=add_menu;
		this.add_cart=add_cart;
	}
	
	public int check()
	{
		 Scanner s=new Scanner(System.in);
	     System.out.print("Enter the Product Category:");
	     String inp_category=s.next().toLowerCase();
		 System.out.print("Enter the Company:");
		 String inp_company=s.next().toLowerCase();
		 Add_menu obj=new Add_menu(category,company,quant,price,check_menu);
		int flag=0;
		for(Add_menu a:check_menu)
		{
			if((a.category.equals(inp_category)) && (a.company.equals(inp_company)))
			{
				System.out.println("Category:"+a.category);
				System.out.println("Comapany:"+a.company);
				System.out.println("Quant:"+a.quant);
				System.out.println("Price:"+a.price);
				flag=1;
				System.out.println("Customer willing to Buy? y");
				String ch=s.next().toLowerCase();
				if(ch.equals("y"))
				{
					System.out.print("Enter the Quantity you like to Buy:");
					int inp_quant=s.nextInt();
					if(a.quant>=inp_quant)
					{
					obj.quant=inp_quant;
					add_cart.add(obj);
					a.quant=(a.quant)-inp_quant;
					}
					else
					{
						System.out.println("Number of Item not available.Out of Stock!!");
					}

				}
				break;
			}
		}
		return flag;
		
	}

}

