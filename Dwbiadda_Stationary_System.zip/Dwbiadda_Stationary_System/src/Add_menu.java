import java.util.*;
public class Add_menu extends Sta_menu {
	 String category;
	 String company;
	 int quant;
	 int price;
	 List<Add_menu> add_menu=new ArrayList<Add_menu>();
	Add_menu(String category,String company,int quant,int price,List<Add_menu> add_menu)
	{
		this.category=category;
		this.company=company;
		this.quant=quant;
		this.price=price;
		this.add_menu=add_menu;
	}
	
	public int check_exist()
	{
		
		int flag=0;
		for(Add_menu a:add_menu)
		{
			if((a.category.equals(category)) && (a.company.equals(company)))
			{
				
				System.out.println("The Item is already Available in Menu:");
				System.out.println("Category:"+a.category);
				System.out.println("Comapany:"+a.company);
				System.out.println("Quant:"+a.quant);
				System.out.println("Price:"+a.price);
				flag=1;
				break;
			}
		}
		return flag;
		
	}
     public void update_menu(int option)
     {
 		for(Add_menu a:add_menu)
 		{
 			 if((a.category.equals(category)) && (a.company.equals(company)) && option== 0)
  			{
 			 a.quant=a.quant+quant;
     	     System.out.println("Category:"+a.category);
 			 System.out.println("Comapany:"+a.company);
 			 System.out.println("Quant:"+a.quant);
 			 System.out.println("Price:"+a.price);
  			}
 			else if((a.category.equals(category)) && (a.company.equals(company)) && option== 1)
 			{
    	     a.price=price;
    	     System.out.println("Category:"+a.category);
			 System.out.println("Comapany:"+a.company);
			 System.out.println("Quant:"+a.quant);
			 System.out.println("Price:"+a.price);
 			}
 			else if((a.category.equals(category)) && (a.company.equals(company)) && option== 2)
 			{
 				a.price=price;
 				a.quant=a.quant+quant;
 				System.out.println("Category:"+a.category);
				System.out.println("Comapany:"+a.company);
				System.out.println("Quant:"+a.quant);
				System.out.println("Price:"+a.price);
 			}
 		   
 		}
 		
     }

	

}
