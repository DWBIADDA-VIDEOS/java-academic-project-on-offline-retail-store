import java.util.*;
public class Dwbiadda_Main_Class {
	
	public static void main(String[] args)
	{
	
	System.out.println("Please enter the MenuItem to add to menu");
	Scanner s=new Scanner(System.in);
	Sta_menu m=new Sta_menu();//Sta_menu class that will have the Menu operations
	m.accept_item();//call the accept_item available in Sta_menu class to add the item
	System.out.println("Select 'add' to Add the Item to Stock");
	System.out.println("Select 'disp' to Display the Content Available");
	System.out.println("Select 'cart' to Add to Cart");
	System.out.println("Select 'bill' to Genrate the Bill");
	System.out.println("Select 'search' to Search the item in the menu");
	System.out.println("Provide any other input to Exit the Menu");
	String choice=s.next().toLowerCase();
	int flag=0;
	while(flag==0)
	{
	switch(choice)
	{
	case "add":
	{
		m.accept_item();
		break;
	}
	case "disp":
	{
		m.print();
		break;
	}
	case "cart":
	{
		m.checking_cart();
		break;
	}
	case "bill":
	{
		m.bill();
		break;
	}
	case "search":
	{
		m.bill();
		break;
	}
	
	default:
	{
		System.out.println("Exiting code!!");
		flag++;
		break;
	}
	}
	if(flag!=0)
	{
		break;
	}
	else
	{
	System.out.println("Please select your choice to proceed");
	choice=s.next().toLowerCase();
	}
	}
	
	}

}
